# Backend scanner

FastAPI backend for the Android widget.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Endpoints

- `GET /health` — status check
- `GET /matches` — returns confirmed live matches only
- `GET /scan?include_rejections=true` — same as `/matches`, optionally includes rejection reasons

## Catalyst source options

For strict social/news engagement, set `SOCIAL_CATALYST_URL`. The backend will call:

```text
<SOCIAL_CATALYST_URL>?symbol=JEM
```

Expected response:

```json
{
  "symbol": "JEM",
  "title": "Example headline or post",
  "url": "https://example.com/story",
  "source": "Stocktwits/X/news analytics provider",
  "views": 50000,
  "baseline_views": 4000,
  "engagement_spike": 12.5,
  "observed_at": "2026-07-01T14:30:00Z"
}
```

If you do not have an engagement API yet, set `REQUIRE_ENGAGEMENT_SPIKE=false` to allow recent stock news to satisfy the catalyst filter. That is less strict.

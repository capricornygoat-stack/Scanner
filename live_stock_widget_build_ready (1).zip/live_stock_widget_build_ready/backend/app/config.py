from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    fmp_api_key: str = ""
    fmp_base_url: str = "https://financialmodelingprep.com"
    candidate_symbols: str = ""
    max_candidates: int = 75
    api_token: str = ""

    require_engagement_spike: bool = True
    social_catalyst_url: str = ""
    catalyst_max_age_minutes: int = 180
    min_engagement_spike_x: float = 5.0

    price_min: float = 1.50
    price_max: float = 10.00
    min_relative_volume: float = 5.0
    min_gain_pct: float = 20.0
    max_float_shares: float = 30_000_000
    market_cap_min: float = 1_000_000
    market_cap_max: float = 100_000_000

    def candidate_symbol_list(self) -> list[str]:
        return [s.strip().upper() for s in self.candidate_symbols.split(",") if s.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()

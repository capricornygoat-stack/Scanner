from __future__ import annotations


def ema(values: list[float], period: int) -> float | None:
    """Return the most recent EMA value for a list ordered oldest -> newest."""
    clean = [float(v) for v in values if v is not None]
    if len(clean) < period:
        return None
    k = 2 / (period + 1)
    current = sum(clean[:period]) / period
    for value in clean[period:]:
        current = (value * k) + (current * (1 - k))
    return current


def macd_line(values: list[float], fast: int = 12, slow: int = 26) -> float | None:
    """Return current MACD line: EMA(fast) - EMA(slow)."""
    if len(values) < slow:
        return None
    fast_ema = ema(values, fast)
    slow_ema = ema(values, slow)
    if fast_ema is None or slow_ema is None:
        return None
    return fast_ema - slow_ema


def intraday_vwap(candles: list[dict]) -> float | None:
    """Calculate session VWAP from intraday candles."""
    pv = 0.0
    volume_sum = 0.0
    for candle in candles:
        try:
            high = float(candle.get("high"))
            low = float(candle.get("low"))
            close = float(candle.get("close"))
            volume = float(candle.get("volume") or 0)
        except (TypeError, ValueError):
            continue
        if volume <= 0:
            continue
        typical = (high + low + close) / 3
        pv += typical * volume
        volume_sum += volume
    if volume_sum <= 0:
        return None
    return pv / volume_sum

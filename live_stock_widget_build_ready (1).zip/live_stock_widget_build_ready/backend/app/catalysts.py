from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo
import httpx

from .config import Settings
from .models import Catalyst

UTC = dt.timezone.utc


class CatalystVerifier:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def verify(self, symbol: str, news_items: list[dict]) -> Catalyst | None:
        social = await self._from_social_service(symbol)
        if social and self._fresh(social.observed_at):
            spike = social.engagement_spike
            if spike is not None and spike >= self.settings.min_engagement_spike_x:
                return social

        recent_news = self._recent_news_catalyst(news_items)
        if recent_news and not self.settings.require_engagement_spike:
            return recent_news

        return None

    async def _from_social_service(self, symbol: str) -> Catalyst | None:
        if not self.settings.social_catalyst_url:
            return None
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(self.settings.social_catalyst_url, params={"symbol": symbol})
                if response.status_code == 404:
                    return None
                response.raise_for_status()
                payload = response.json()
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None
        return Catalyst(
            title=str(payload.get("title") or payload.get("text") or ""),
            url=str(payload.get("url") or ""),
            source=str(payload.get("source") or "social-catalyst"),
            views=_as_float(payload.get("views")),
            baseline_views=_as_float(payload.get("baseline_views")),
            engagement_spike=_as_float(payload.get("engagement_spike")),
            observed_at=str(payload.get("observed_at") or payload.get("published_at") or ""),
        )

    def _recent_news_catalyst(self, news_items: list[dict]) -> Catalyst | None:
        for item in news_items:
            observed = str(item.get("publishedDate") or item.get("published_at") or item.get("date") or "")
            if not self._fresh(observed):
                continue
            return Catalyst(
                title=str(item.get("title") or item.get("headline") or "Recent stock news"),
                url=str(item.get("url") or item.get("link") or ""),
                source=str(item.get("site") or item.get("publisher") or "FMP news"),
                observed_at=observed,
            )
        return None

    def _fresh(self, observed_at: str) -> bool:
        parsed = _parse_dt(observed_at)
        if not parsed:
            return False
        age = dt.datetime.now(UTC) - parsed.astimezone(UTC)
        return 0 <= age.total_seconds() <= self.settings.catalyst_max_age_minutes * 60


def _parse_dt(value: str) -> dt.datetime | None:
    if not value:
        return None
    text = value.strip().replace("Z", "+00:00")
    for candidate in (text, text.replace(" ", "T")):
        try:
            parsed = dt.datetime.fromisoformat(candidate)
            if parsed.tzinfo is None:
                # Treat naive market/news timestamps as New York time.
                parsed = parsed.replace(tzinfo=ZoneInfo("America/New_York"))
            return parsed
        except ValueError:
            pass
    return None


def _as_float(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo
import httpx

from .config import Settings


class FmpMarketData:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.base_url = settings.fmp_base_url.rstrip("/")

    async def _get(self, path: str, params: dict | None = None) -> list | dict:
        if not self.settings.fmp_api_key:
            raise RuntimeError("FMP_API_KEY is not configured")
        params = dict(params or {})
        params["apikey"] = self.settings.fmp_api_key
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

    async def candidate_symbols(self) -> list[str]:
        explicit = self.settings.candidate_symbol_list()
        if explicit:
            return explicit[: self.settings.max_candidates]

        # FMP's stable Top Stock Gainers endpoint.
        data = await self._get("/stable/biggest-gainers")
        symbols: list[str] = []
        if isinstance(data, list):
            for item in data:
                symbol = str(item.get("symbol") or item.get("ticker") or "").upper().strip()
                if symbol and symbol not in symbols:
                    symbols.append(symbol)
        return symbols[: self.settings.max_candidates]

    async def quote(self, symbol: str) -> dict:
        data = await self._get("/stable/quote", {"symbol": symbol})
        if isinstance(data, list) and data:
            return data[0]
        if isinstance(data, dict):
            return data
        return {}

    async def share_float(self, symbol: str) -> dict:
        data = await self._get("/stable/shares-float", {"symbol": symbol})
        if isinstance(data, list) and data:
            return data[0]
        if isinstance(data, dict):
            return data
        return {}

    async def daily_candles(self, symbol: str) -> list[dict]:
        data = await self._get("/stable/historical-price-eod/light", {"symbol": symbol})
        rows = data if isinstance(data, list) else data.get("historical", []) if isinstance(data, dict) else []
        return _oldest_to_newest(rows)

    async def intraday_candles_today(self, symbol: str) -> list[dict]:
        today = dt.datetime.now(ZoneInfo("America/New_York")).date().isoformat()
        data = await self._get(
            "/stable/historical-chart/1min",
            {"symbol": symbol, "from": today, "to": today},
        )
        rows = data if isinstance(data, list) else []
        return _oldest_to_newest(rows)

    async def stock_news(self, symbol: str) -> list[dict]:
        # Recent stock news / press style catalyst source. Exact fields can vary by account/plan.
        data = await self._get("/stable/news/stock", {"symbols": symbol, "page": 0, "limit": 10})
        return data if isinstance(data, list) else []


def _oldest_to_newest(rows: list[dict]) -> list[dict]:
    def key(row: dict) -> str:
        return str(row.get("date") or row.get("datetime") or row.get("timestamp") or "")
    return sorted(rows, key=key)


def fnum(value) -> float | None:
    if value is None:
        return None
    if isinstance(value, str):
        value = value.replace("%", "").replace(",", "").strip()
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

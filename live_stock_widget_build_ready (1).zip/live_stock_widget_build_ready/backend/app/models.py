from __future__ import annotations
from pydantic import BaseModel
from typing import Any


class Catalyst(BaseModel):
    title: str = ""
    url: str = ""
    source: str = ""
    views: float | None = None
    baseline_views: float | None = None
    engagement_spike: float | None = None
    observed_at: str = ""


class StockMatch(BaseModel):
    symbol: str
    price: float
    gain_pct: float
    relative_volume: float
    float_shares: float
    market_cap: float
    ema9: float
    ema20: float
    macd: float
    vwap: float
    catalyst: Catalyst
    verified_at: str


class Rejection(BaseModel):
    symbol: str
    reason: str
    values: dict[str, Any] = {}


class ScanResponse(BaseModel):
    generated_at: str
    source_policy: str = "live_current_only_exclude_unverified"
    matches: list[StockMatch]
    rejected_count: int = 0
    rejections: list[Rejection] = []

from __future__ import annotations
import datetime as dt
from zoneinfo import ZoneInfo

from .config import Settings
from .indicators import ema, macd_line, intraday_vwap
from .market_data import FmpMarketData, fnum
from .catalysts import CatalystVerifier
from .models import StockMatch, Rejection, ScanResponse

UTC = dt.timezone.utc


class LiveStockScanner:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.market = FmpMarketData(settings)
        self.catalysts = CatalystVerifier(settings)

    async def scan(self, include_rejections: bool = False) -> ScanResponse:
        generated_at = dt.datetime.now(UTC).isoformat()
        matches: list[StockMatch] = []
        rejections: list[Rejection] = []

        try:
            symbols = await self.market.candidate_symbols()
        except Exception as exc:
            return ScanResponse(
                generated_at=generated_at,
                matches=[],
                rejected_count=1,
                rejections=[Rejection(symbol="*", reason=f"candidate source unavailable: {exc}")],
            )

        for symbol in symbols:
            try:
                result = await self._check_symbol(symbol)
                if isinstance(result, StockMatch):
                    matches.append(result)
                else:
                    rejections.append(result)
            except Exception as exc:
                rejections.append(Rejection(symbol=symbol, reason=f"unverified/error: {exc}"))

        return ScanResponse(
            generated_at=generated_at,
            matches=matches,
            rejected_count=len(rejections),
            rejections=rejections if include_rejections else [],
        )

    async def _check_symbol(self, symbol: str) -> StockMatch | Rejection:
        quote = await self.market.quote(symbol)
        price = fnum(_first(quote, "price", "previousClose", "close"))
        gain_pct = fnum(_first(quote, "changesPercentage", "changePercentage", "changes_percent"))
        volume = fnum(_first(quote, "volume"))
        avg_volume = fnum(_first(quote, "avgVolume", "averageVolume"))
        market_cap = fnum(_first(quote, "marketCap", "market_cap"))

        if price is None:
            return Rejection(symbol=symbol, reason="live price unavailable", values=quote)
        if not (self.settings.price_min <= price <= self.settings.price_max):
            return Rejection(symbol=symbol, reason="price outside range", values={"price": price})
        if gain_pct is None or gain_pct < self.settings.min_gain_pct:
            return Rejection(symbol=symbol, reason="gain below threshold or unavailable", values={"gain_pct": gain_pct})
        if volume is None or avg_volume is None or avg_volume <= 0:
            return Rejection(symbol=symbol, reason="relative volume unavailable", values={"volume": volume, "avg_volume": avg_volume})
        rel_vol = volume / avg_volume
        if rel_vol < self.settings.min_relative_volume:
            return Rejection(symbol=symbol, reason="relative volume below threshold", values={"relative_volume": rel_vol})
        if market_cap is None or not (self.settings.market_cap_min <= market_cap <= self.settings.market_cap_max):
            return Rejection(symbol=symbol, reason="market cap outside range or unavailable", values={"market_cap": market_cap})

        share_float = await self.market.share_float(symbol)
        float_shares = fnum(_first(share_float, "floatShares", "freeFloat", "float", "sharesFloat"))
        if float_shares is None or float_shares > self.settings.max_float_shares:
            return Rejection(symbol=symbol, reason="float outside range or unavailable", values=share_float)

        daily = await self.market.daily_candles(symbol)
        closes = [fnum(row.get("close") or row.get("price")) for row in daily]
        closes = [x for x in closes if x is not None]
        ema9 = ema(closes, 9)
        ema20 = ema(closes, 20)
        macd = macd_line(closes)
        if ema9 is None or ema20 is None or macd is None:
            return Rejection(symbol=symbol, reason="EMA/MACD unavailable", values={"daily_points": len(closes)})
        if not (price < ema9 and price < ema20):
            return Rejection(symbol=symbol, reason="price not below both EMAs", values={"price": price, "ema9": ema9, "ema20": ema20})
        if macd >= 0:
            return Rejection(symbol=symbol, reason="MACD is not below zero", values={"macd": macd})

        intraday = await self.market.intraday_candles_today(symbol)
        vwap = intraday_vwap(intraday)
        if vwap is None:
            return Rejection(symbol=symbol, reason="VWAP unavailable", values={"intraday_points": len(intraday)})
        if price >= vwap:
            return Rejection(symbol=symbol, reason="price not below VWAP", values={"price": price, "vwap": vwap})

        news = await self.market.stock_news(symbol)
        catalyst = await self.catalysts.verify(symbol, news)
        if catalyst is None:
            return Rejection(symbol=symbol, reason="live catalyst/engagement spike not verified")

        return StockMatch(
            symbol=symbol,
            price=round(price, 4),
            gain_pct=round(gain_pct, 2),
            relative_volume=round(rel_vol, 2),
            float_shares=float_shares,
            market_cap=market_cap,
            ema9=round(ema9, 4),
            ema20=round(ema20, 4),
            macd=round(macd, 4),
            vwap=round(vwap, 4),
            catalyst=catalyst,
            verified_at=dt.datetime.now(UTC).isoformat(),
        )


def _first(mapping: dict, *names: str):
    for name in names:
        if name in mapping and mapping[name] not in (None, ""):
            return mapping[name]
    return None

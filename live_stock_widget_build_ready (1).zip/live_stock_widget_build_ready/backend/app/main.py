from __future__ import annotations
from fastapi import Depends, FastAPI, Header, HTTPException, Query

from .config import Settings, get_settings
from .models import ScanResponse
from .scanner import LiveStockScanner

app = FastAPI(title="Live Stock Screener", version="1.0.0")


def require_auth(
    authorization: str | None = Header(default=None),
    settings: Settings = Depends(get_settings),
):
    if not settings.api_token:
        return
    expected = f"Bearer {settings.api_token}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="Invalid or missing token")


@app.get("/health")
async def health(settings: Settings = Depends(get_settings)):
    return {
        "ok": True,
        "source_policy": "live_current_only_exclude_unverified",
        "has_fmp_key": bool(settings.fmp_api_key),
        "strict_engagement_spike": settings.require_engagement_spike,
    }


@app.get("/matches", response_model=ScanResponse, dependencies=[Depends(require_auth)])
async def matches(settings: Settings = Depends(get_settings)):
    scanner = LiveStockScanner(settings)
    return await scanner.scan(include_rejections=False)


@app.get("/scan", response_model=ScanResponse, dependencies=[Depends(require_auth)])
async def scan(
    include_rejections: bool = Query(default=False),
    settings: Settings = Depends(get_settings),
):
    scanner = LiveStockScanner(settings)
    return await scanner.scan(include_rejections=include_rejections)

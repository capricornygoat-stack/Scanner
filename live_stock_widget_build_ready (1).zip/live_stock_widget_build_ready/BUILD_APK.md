# Build the installable Android APK

This package contains Android source plus a FastAPI backend. I could not compile the APK inside the ChatGPT sandbox because the sandbox does not include the Android SDK, Gradle, Android build tools, or network access to download them.

## Easiest: build in Android Studio

1. Install Android Studio on your computer.
2. Open the `android/` folder from this project.
3. Let Android Studio sync/download Gradle and Android SDK packages.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your Android phone.

The debug APK will usually be at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Build from command line

From the `android/` folder:

```bash
gradle :app:assembleDebug
```

or, if Android Studio creates a Gradle wrapper for you:

```bash
./gradlew :app:assembleDebug
```

## Build with GitHub Actions

This package includes `.github/workflows/build-apk.yml`.

1. Create a new GitHub repository.
2. Upload this project so the `android/` folder is at the repo root.
3. Open the **Actions** tab.
4. Run **Build Android Debug APK**.
5. Download the artifact named `LiveStockScanner-debug-apk`.

## Install on your phone

1. Copy `app-debug.apk` to your phone.
2. Open it from Files/Downloads.
3. Allow installation from that source when Android prompts you.
4. Open **Live Stock Scanner**, enter your backend URL, save, then add the **Live Stock Scanner** widget to your home screen.

## Backend reminder

The widget needs the backend scanner running at a reachable URL. `http://10.0.2.2:8000` only works from an Android emulator. For a real phone, use a URL the phone can reach, such as:

- `http://<your-computer-LAN-IP>:8000` while on the same Wi‑Fi, or
- a deployed HTTPS backend URL.

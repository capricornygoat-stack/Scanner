package com.stockscanner.widget

object Constants {
    const val PREFS = "stock_scanner_prefs"
    const val KEY_API_BASE_URL = "api_base_url"
    const val KEY_API_TOKEN = "api_token"
    const val KEY_LAST_JSON = "last_json"
    const val KEY_LAST_UPDATED = "last_updated"
    const val KEY_LAST_ERROR = "last_error"
    const val KEY_LAST_SIGNATURE = "last_signature"

    const val DEFAULT_API_BASE_URL = "http://10.0.2.2:8000"
    const val ACTION_REFRESH = "com.stockscanner.widget.REFRESH"
    const val WORK_PERIODIC = "live_stock_scanner_periodic"
    const val WORK_REFRESH_NOW = "live_stock_scanner_refresh_now"
    const val CHANNEL_ID = "stock_scanner_alerts"
}

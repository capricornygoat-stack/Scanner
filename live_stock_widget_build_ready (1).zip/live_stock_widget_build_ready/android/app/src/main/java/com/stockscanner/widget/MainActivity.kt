package com.stockscanner.widget

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences(Constants.PREFS, MODE_PRIVATE)
        val apiUrl = findViewById<EditText>(R.id.apiUrl)
        val apiToken = findViewById<EditText>(R.id.apiToken)
        val status = findViewById<TextView>(R.id.status)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val refreshButton = findViewById<Button>(R.id.refreshButton)

        apiUrl.setText(prefs.getString(Constants.KEY_API_BASE_URL, Constants.DEFAULT_API_BASE_URL))
        apiToken.setText(prefs.getString(Constants.KEY_API_TOKEN, ""))
        status.text = prefs.getString(Constants.KEY_LAST_ERROR, "Ready. Add the widget to your home screen.")

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        saveButton.setOnClickListener {
            prefs.edit()
                .putString(Constants.KEY_API_BASE_URL, apiUrl.text.toString().trim().trimEnd('/'))
                .putString(Constants.KEY_API_TOKEN, apiToken.text.toString().trim())
                .remove(Constants.KEY_LAST_ERROR)
                .apply()
            WorkScheduler.schedulePeriodic(this)
            ScannerWorker.enqueueNow(this)
            status.text = "Saved. Scanner scheduled and refresh requested."
        }

        refreshButton.setOnClickListener {
            ScannerWorker.enqueueNow(this)
            status.text = "Refresh requested. Check the widget in a moment."
        }
    }
}

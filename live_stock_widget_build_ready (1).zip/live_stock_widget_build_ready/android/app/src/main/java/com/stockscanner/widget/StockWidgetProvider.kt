package com.stockscanner.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONArray

class StockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WorkScheduler.schedulePeriodic(context)
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == Constants.ACTION_REFRESH) {
            ScannerWorker.enqueueNow(context)
            updateAll(context)
        }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, StockWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences(Constants.PREFS, Context.MODE_PRIVATE)
            val error = prefs.getString(Constants.KEY_LAST_ERROR, null)
            val updated = prefs.getString(Constants.KEY_LAST_UPDATED, "Never") ?: "Never"
            val json = prefs.getString(Constants.KEY_LAST_JSON, "[]") ?: "[]"
            val matches = JSONArray(json)

            val views = RemoteViews(context.packageName, R.layout.stock_widget)
            views.setTextViewText(R.id.widgetTitle, "Live Stock Scanner")
            views.setTextViewText(R.id.widgetUpdated, "Updated: $updated")

            if (error != null) {
                views.setTextViewText(R.id.widgetStatus, "Error")
                views.setTextViewText(R.id.widgetTickers, error.take(180))
            } else if (matches.length() == 0) {
                views.setTextViewText(R.id.widgetStatus, "No confirmed matches")
                views.setTextViewText(R.id.widgetTickers, "Live-only filters are strict. Tap Refresh to check now.")
            } else {
                views.setTextViewText(R.id.widgetStatus, "${matches.length()} confirmed match${if (matches.length() == 1) "" else "es"}")
                val lines = mutableListOf<String>()
                for (i in 0 until minOf(matches.length(), 4)) {
                    val item = matches.getJSONObject(i)
                    lines.add("${item.optString("symbol")}  $${"%.2f".format(item.optDouble("price"))}  +${"%.1f".format(item.optDouble("gain_pct"))}%  RVOL ${"%.1f".format(item.optDouble("relative_volume"))}x")
                }
                views.setTextViewText(R.id.widgetTickers, lines.joinToString("\n"))
            }

            val refreshIntent = Intent(context, StockWidgetProvider::class.java).apply { action = Constants.ACTION_REFRESH }
            val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_UPDATE_CURRENT
            val pending = PendingIntent.getBroadcast(context, 1002, refreshIntent, flags)
            views.setOnClickPendingIntent(R.id.refreshButton, pending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}

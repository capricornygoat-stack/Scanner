package com.stockscanner.widget

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ScannerApi {
    fun fetchMatches(baseUrl: String, token: String): List<StockMatch> {
        val url = URL(baseUrl.trimEnd('/') + "/matches")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        val code = connection.responseCode
        val body = if (code in 200..299) {
            connection.inputStream.bufferedReader().use { it.readText() }
        } else {
            connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
        }
        if (code !in 200..299) throw IllegalStateException("Backend error $code: $body")

        val root = JSONObject(body)
        val matches = root.optJSONArray("matches") ?: JSONArray()
        return (0 until matches.length()).map { i ->
            val item = matches.getJSONObject(i)
            val catalyst = item.optJSONObject("catalyst")
            StockMatch(
                symbol = item.optString("symbol"),
                price = item.optDouble("price"),
                gainPct = item.optDouble("gain_pct"),
                relativeVolume = item.optDouble("relative_volume"),
                floatShares = item.optDouble("float_shares"),
                marketCap = item.optDouble("market_cap"),
                ema9 = item.optDouble("ema9"),
                ema20 = item.optDouble("ema20"),
                macd = item.optDouble("macd"),
                vwap = item.optDouble("vwap"),
                catalystTitle = catalyst?.optString("title") ?: "Catalyst verified",
                catalystUrl = catalyst?.optString("url") ?: ""
            )
        }
    }
}

data class StockMatch(
    val symbol: String,
    val price: Double,
    val gainPct: Double,
    val relativeVolume: Double,
    val floatShares: Double,
    val marketCap: Double,
    val ema9: Double,
    val ema20: Double,
    val macd: Double,
    val vwap: Double,
    val catalystTitle: String,
    val catalystUrl: String
)

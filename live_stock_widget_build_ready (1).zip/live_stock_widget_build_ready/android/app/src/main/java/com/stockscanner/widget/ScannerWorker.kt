package com.stockscanner.widget

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

class ScannerWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(Constants.PREFS, Context.MODE_PRIVATE)
        val baseUrl = prefs.getString(Constants.KEY_API_BASE_URL, Constants.DEFAULT_API_BASE_URL) ?: Constants.DEFAULT_API_BASE_URL
        val token = prefs.getString(Constants.KEY_API_TOKEN, "") ?: ""

        return try {
            val matches = ScannerApi.fetchMatches(baseUrl, token)
            val json = matchesToJson(matches)
            val signature = matches.joinToString("|") { "${it.symbol}:${it.price}:${it.gainPct}" }
            val previousSignature = prefs.getString(Constants.KEY_LAST_SIGNATURE, "") ?: ""

            prefs.edit()
                .putString(Constants.KEY_LAST_JSON, json.toString())
                .putString(Constants.KEY_LAST_UPDATED, Instant.now().toString())
                .remove(Constants.KEY_LAST_ERROR)
                .putString(Constants.KEY_LAST_SIGNATURE, signature)
                .apply()

            StockWidgetProvider.updateAll(applicationContext)
            if (matches.isNotEmpty() && signature != previousSignature) {
                Notifier.showMatchNotification(applicationContext, matches)
            }
            Result.success()
        } catch (e: Exception) {
            prefs.edit()
                .putString(Constants.KEY_LAST_ERROR, e.message ?: "Unknown scanner error")
                .putString(Constants.KEY_LAST_UPDATED, Instant.now().toString())
                .apply()
            StockWidgetProvider.updateAll(applicationContext)
            Result.retry()
        }
    }

    private fun matchesToJson(matches: List<StockMatch>): JSONArray {
        val array = JSONArray()
        matches.forEach { match ->
            array.put(JSONObject().apply {
                put("symbol", match.symbol)
                put("price", match.price)
                put("gain_pct", match.gainPct)
                put("relative_volume", match.relativeVolume)
                put("float_shares", match.floatShares)
                put("market_cap", match.marketCap)
                put("ema9", match.ema9)
                put("ema20", match.ema20)
                put("macd", match.macd)
                put("vwap", match.vwap)
                put("catalyst_title", match.catalystTitle)
                put("catalyst_url", match.catalystUrl)
            })
        }
        return array
    }

    companion object {
        fun enqueueNow(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequest.Builder(ScannerWorker::class.java)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                Constants.WORK_REFRESH_NOW,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}

object Notifier {
    fun showMatchNotification(context: Context, matches: List<StockMatch>) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(Constants.CHANNEL_ID, "Stock scanner alerts", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val title = "${matches.size} stock scanner match${if (matches.size == 1) "" else "es"}"
        val text = matches.take(5).joinToString(", ") { "${it.symbol} $${"%.2f".format(it.price)}" }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(context, Constants.CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(context)
        }
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        manager.notify(2001, notification)
    }
}

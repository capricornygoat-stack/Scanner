plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.stockscanner.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.stockscanner.widget"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.work:work-runtime:2.10.0")
}
